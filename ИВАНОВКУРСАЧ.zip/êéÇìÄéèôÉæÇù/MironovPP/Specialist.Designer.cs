﻿namespace MironovPP
{
    partial class Specialist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Warehouse = new System.Windows.Forms.Button();
            this.DetailKolvo = new System.Windows.Forms.TextBox();
            this.DeclineRequest = new System.Windows.Forms.Button();
            this.AcceptRequest = new System.Windows.Forms.Button();
            this.DetailNumber = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.IDRequest = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Search = new System.Windows.Forms.Button();
            this.dataGridViewAdmin = new System.Windows.Forms.DataGridView();
            this.Close = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAdmin)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.Warehouse);
            this.panel1.Controls.Add(this.DetailKolvo);
            this.panel1.Controls.Add(this.DeclineRequest);
            this.panel1.Controls.Add(this.AcceptRequest);
            this.panel1.Controls.Add(this.DetailNumber);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.IDRequest);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.Search);
            this.panel1.Controls.Add(this.dataGridViewAdmin);
            this.panel1.Controls.Add(this.Close);
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(436, 383);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Warehouse
            // 
            this.Warehouse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Warehouse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Warehouse.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.Warehouse.FlatAppearance.BorderSize = 0;
            this.Warehouse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Warehouse.Font = new System.Drawing.Font("Vivaldi", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Warehouse.ForeColor = System.Drawing.Color.White;
            this.Warehouse.Location = new System.Drawing.Point(277, 347);
            this.Warehouse.Margin = new System.Windows.Forms.Padding(4);
            this.Warehouse.Name = "Warehouse";
            this.Warehouse.Size = new System.Drawing.Size(137, 25);
            this.Warehouse.TabIndex = 91;
            this.Warehouse.Text = "Склад";
            this.Warehouse.UseVisualStyleBackColor = false;
            // 
            // DetailKolvo
            // 
            this.DetailKolvo.BackColor = System.Drawing.Color.DarkGray;
            this.DetailKolvo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DetailKolvo.Font = new System.Drawing.Font("Georgia", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DetailKolvo.ForeColor = System.Drawing.Color.Black;
            this.DetailKolvo.Location = new System.Drawing.Point(277, 304);
            this.DetailKolvo.Margin = new System.Windows.Forms.Padding(4);
            this.DetailKolvo.Name = "DetailKolvo";
            this.DetailKolvo.Size = new System.Drawing.Size(137, 24);
            this.DetailKolvo.TabIndex = 89;
            // 
            // DeclineRequest
            // 
            this.DeclineRequest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.DeclineRequest.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DeclineRequest.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.DeclineRequest.FlatAppearance.BorderSize = 0;
            this.DeclineRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeclineRequest.Font = new System.Drawing.Font("Vivaldi", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeclineRequest.ForeColor = System.Drawing.Color.White;
            this.DeclineRequest.Location = new System.Drawing.Point(149, 347);
            this.DeclineRequest.Margin = new System.Windows.Forms.Padding(4);
            this.DeclineRequest.Name = "DeclineRequest";
            this.DeclineRequest.Size = new System.Drawing.Size(115, 25);
            this.DeclineRequest.TabIndex = 88;
            this.DeclineRequest.Text = "Отклонить";
            this.DeclineRequest.UseVisualStyleBackColor = false;
            // 
            // AcceptRequest
            // 
            this.AcceptRequest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.AcceptRequest.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AcceptRequest.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.AcceptRequest.FlatAppearance.BorderSize = 0;
            this.AcceptRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AcceptRequest.Font = new System.Drawing.Font("Vivaldi", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AcceptRequest.ForeColor = System.Drawing.Color.White;
            this.AcceptRequest.Location = new System.Drawing.Point(15, 347);
            this.AcceptRequest.Margin = new System.Windows.Forms.Padding(4);
            this.AcceptRequest.Name = "AcceptRequest";
            this.AcceptRequest.Size = new System.Drawing.Size(126, 25);
            this.AcceptRequest.TabIndex = 87;
            this.AcceptRequest.Text = "Выполнить";
            this.AcceptRequest.UseVisualStyleBackColor = false;
            // 
            // DetailNumber
            // 
            this.DetailNumber.BackColor = System.Drawing.Color.DarkGray;
            this.DetailNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DetailNumber.Font = new System.Drawing.Font("Georgia", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DetailNumber.ForeColor = System.Drawing.Color.Black;
            this.DetailNumber.Location = new System.Drawing.Point(149, 304);
            this.DetailNumber.Margin = new System.Windows.Forms.Padding(4);
            this.DetailNumber.Name = "DetailNumber";
            this.DetailNumber.Size = new System.Drawing.Size(115, 24);
            this.DetailNumber.TabIndex = 85;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(15, 278);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 20);
            this.label3.TabIndex = 84;
            this.label3.Text = "№ Заявки";
            // 
            // IDRequest
            // 
            this.IDRequest.BackColor = System.Drawing.Color.DarkGray;
            this.IDRequest.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.IDRequest.Font = new System.Drawing.Font("Georgia", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.IDRequest.ForeColor = System.Drawing.Color.Black;
            this.IDRequest.Location = new System.Drawing.Point(15, 304);
            this.IDRequest.Margin = new System.Windows.Forms.Padding(4);
            this.IDRequest.Name = "IDRequest";
            this.IDRequest.Size = new System.Drawing.Size(126, 24);
            this.IDRequest.TabIndex = 83;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Vivaldi", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(11, 63);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(233, 22);
            this.label2.TabIndex = 82;
            this.label2.Text = "Текущие заявки на ремонт -";
            // 
            // Search
            // 
            this.Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Search.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.Search.FlatAppearance.BorderSize = 0;
            this.Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Search.Font = new System.Drawing.Font("Vivaldi", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search.ForeColor = System.Drawing.Color.White;
            this.Search.Location = new System.Drawing.Point(105, 229);
            this.Search.Margin = new System.Windows.Forms.Padding(4);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(216, 25);
            this.Search.TabIndex = 81;
            this.Search.Text = "Поиск";
            this.Search.UseVisualStyleBackColor = false;
            // 
            // dataGridViewAdmin
            // 
            this.dataGridViewAdmin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAdmin.Location = new System.Drawing.Point(15, 88);
            this.dataGridViewAdmin.Name = "dataGridViewAdmin";
            this.dataGridViewAdmin.RowHeadersVisible = false;
            this.dataGridViewAdmin.Size = new System.Drawing.Size(399, 134);
            this.dataGridViewAdmin.TabIndex = 80;
            // 
            // Close
            // 
            this.Close.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Close.Location = new System.Drawing.Point(398, 3);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(33, 25);
            this.Close.TabIndex = 79;
            this.Close.Text = "X";
            this.Close.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(145, 278);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 20);
            this.label1.TabIndex = 92;
            this.label1.Text = "№ Детали";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(273, 278);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 20);
            this.label4.TabIndex = 93;
            this.label4.Text = "Количество";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label5.Location = new System.Drawing.Point(130, 3);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(201, 29);
            this.label5.TabIndex = 94;
            this.label5.Text = "Ремонт машин";
            // 
            // Specialist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 408);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Specialist";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Specialist";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAdmin)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Warehouse;
        private System.Windows.Forms.TextBox DetailKolvo;
        private System.Windows.Forms.Button DeclineRequest;
        private System.Windows.Forms.Button AcceptRequest;
        private System.Windows.Forms.TextBox DetailNumber;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox IDRequest;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.DataGridView dataGridViewAdmin;
        private System.Windows.Forms.Button Close;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
    }
}