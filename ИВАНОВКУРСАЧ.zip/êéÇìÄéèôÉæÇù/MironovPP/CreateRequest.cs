﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MironovPP
{
    public partial class CreateRequest : Form
    {
         private string connectionString = "Data Source=DESKTOP-CTEHH5B\\SQLEXPRESS;Initial Catalog=CarSharing;Integrated Security=True;Encrypt=False";
        public CreateRequest()
        {
            InitializeComponent();
        }

        private void CreateOrder_Click(object sender, EventArgs e)
        {
            string problem = Problem.Text;
            string phoneNumber = Phone.Text;
            string numberId = NumberId.Text;

            if (string.IsNullOrEmpty(problem) || string.IsNullOrEmpty(phoneNumber) || string.IsNullOrEmpty(numberId))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO Заявки (Категория, НомерТелефона, IDМашины, Статус) VALUES (@Category, @PhoneNumber, @NumberId, @Status)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Category", "Починка");
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                        command.Parameters.AddWithValue("@NumberId", numberId);
                        command.Parameters.AddWithValue("@Status", "В обработке");

                        int result = command.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show("Заявка успешно создана.");
                        }
                        else
                        {
                            MessageBox.Show("Не удалось создать заявку.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при выполнении запроса: " + ex.Message);
            }
        }
        private void Close_Click(object sender, EventArgs e)
        {
            User user = new User();
            user.Show();
            this.Close();
        }
    }
}
