﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MironovPP
{
    public partial class Request : Form
    {
        private string connectionString = "Data Source=DESKTOP-CTEHH5B\\SQLEXPRESS;Initial Catalog=CarSharing;Integrated Security=True;Encrypt=False";

        public Request()
        {
            InitializeComponent();
        }

        private void CheckOrder_Click(object sender, EventArgs e)
        {
            string category = CategorList.Text;
            string phoneNumber = Phone.Text;

            if (string.IsNullOrEmpty(category) || string.IsNullOrEmpty(phoneNumber))
            {
                MessageBox.Show("Пожалуйста, заполните поля категории и номера телефона.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Заявки WHERE Категория = @Category AND НомерТелефона = @PhoneNumber";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Category", category);
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);

                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            if (dataTable.Rows.Count > 0)
                            {
                                dataGridViewRequest.DataSource = dataTable;
                            }
                            else
                            {
                                MessageBox.Show("Заявка не найдена.");
                                dataGridViewRequest.DataSource = null;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при выполнении запроса: " + ex.Message);
            }
        }

        private void Close_Click(object sender, EventArgs e)
        {
           User user = new User();
           user.Show();
           this.Close();
        }
    }
    }
