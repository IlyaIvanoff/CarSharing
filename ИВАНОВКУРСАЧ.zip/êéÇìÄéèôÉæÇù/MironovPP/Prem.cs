﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MironovPP
{
    public partial class Prem : Form
    {
        private string connectionString = "Data Source=DESKTOP-CTEHH5B\\SQLEXPRESS;Initial Catalog=CarSharing;Integrated Security=True;Encrypt=False";

        public Prem()
        {
            InitializeComponent();
        }

        private void Prem_Load(object sender, EventArgs e)
        {

        }

        private void GoToCart_Click(object sender, EventArgs e)
        {
            Request request = new Request();
            request.Show();
            this.Hide();
        }

        private void AddToCart_Click(object sender, EventArgs e)
        {
            string carId = CarID.Text;
            string phoneNumber = Phone.Text;

            if (string.IsNullOrEmpty(carId) || string.IsNullOrEmpty(phoneNumber))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO Заявки (ОписаниеПроблемы, IDМашины, НомерТелефона, Статус, Категория) VALUES (@ProblemDescription, @CarID, @PhoneNumber, @Status, @Category)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ProblemDescription", "нет");
                        command.Parameters.AddWithValue("@CarID", carId);
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                        command.Parameters.AddWithValue("@Status", "В обработке");
                        command.Parameters.AddWithValue("@Category", "Аренда");

                        int result = command.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show("Заявка успешно добавлена в статусе 'В обработке'.");
                        }
                        else
                        {
                            MessageBox.Show("Не удалось добавить заявку.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при выполнении запроса: " + ex.Message);
            }
        }
        private void Close_Click(object sender, EventArgs e)
        {
            User user = new User();
            user.Show();
            this.Close();
        }
    }
    }
