﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MironovPP
{
    public partial class Admin : Form
    {
        string connectionString = @"Data Source=DESKTOP-CTEHH5B\SQLEXPRESS;Initial Catalog=CarSharing;Integrated Security=True;Encrypt=False";
        public Admin()
        {
            InitializeComponent();
        }
        private void Close_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Close();
        }
        private void Search_Click_2(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Заявки";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        // Открываем подключение и создаем адаптер данных
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();

                        // Заполняем таблицу данными из базы данных
                        adapter.Fill(dataTable);

                        // Привязываем таблицу к элементу управления DataGridView
                        dataGridViewAdmin.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при выполнении запроса: " + ex.Message);
                    }
                }
            }
        }

        private void CancelOrder_Click(object sender, EventArgs e)
        {
            string requestId = IDRequest.Text;
            if (string.IsNullOrEmpty(requestId))
            {
                MessageBox.Show("Пожалуйста, введите ID заявки.");
                return;
            }

            int requestIdInt;
            if (!int.TryParse(requestId, out requestIdInt))
            {
                MessageBox.Show("ID заявки должен быть числом.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    // Проверяем, существует ли заявка с указанным ID
                    string checkQuery = "SELECT COUNT(*) FROM Заявки WHERE IDOrder = @RequestId";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@RequestId", requestIdInt);
                        int count = (int)checkCommand.ExecuteScalar();

                        if (count == 0)
                        {
                            MessageBox.Show("Заявка с указанным ID не найдена.");
                            return;
                        }
                    }

                    // Обновляем статус заявки
                    string updateQuery = "UPDATE Заявки SET Статус = @Status WHERE IDOrder = @RequestId";
                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@Status", "Отклонено");
                        updateCommand.Parameters.AddWithValue("@RequestId", requestIdInt);
                        int result = updateCommand.ExecuteNonQuery();
                        if (result > 0)
                        {
                            MessageBox.Show("Статус заявки успешно обновлён.");
                        }
                        else
                        {
                            MessageBox.Show("Не удалось обновить статус заявки.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при выполнении запроса: " + ex.Message);
            }
        }
        private void AcceptOrder_Click(object sender, EventArgs e)
        {
            string requestId = IDRequest.Text;
            if (string.IsNullOrEmpty(requestId))
            {
                MessageBox.Show("Пожалуйста, введите ID заявки.");
                return;
            }

            int requestIdInt;
            if (!int.TryParse(requestId, out requestIdInt))
            {
                MessageBox.Show("ID заявки должен быть числом.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    // Проверяем, существует ли заявка с указанным ID
                    string checkQuery = "SELECT COUNT(*) FROM Заявки WHERE IDOrder = @RequestId";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@RequestId", requestIdInt);
                        int count = (int)checkCommand.ExecuteScalar();

                        if (count == 0)
                        {
                            MessageBox.Show("Заявка с указанным ID не найдена.");
                            return;
                        }
                    }

                    // Обновляем статус заявки
                    string updateQuery = "UPDATE Заявки SET Статус = @Status WHERE IDOrder = @RequestId";
                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@Status", "Принято");
                        updateCommand.Parameters.AddWithValue("@RequestId", requestIdInt);
                        int result = updateCommand.ExecuteNonQuery();
                        if (result > 0)
                        {
                            MessageBox.Show("Статус заявки успешно обновлён.");
                        }
                        else
                        {
                            MessageBox.Show("Не удалось обновить статус заявки.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при выполнении запроса: " + ex.Message);
            }
        }

        private void Close_Click_1(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }
    }
}
