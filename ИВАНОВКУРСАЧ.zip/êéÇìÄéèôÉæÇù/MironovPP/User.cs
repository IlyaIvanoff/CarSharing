﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MironovPP
{
    public partial class User : Form
    {
        public User()
        {
            InitializeComponent();
        }
        private void GoToPrem_Click(object sender, EventArgs e)
        {
            Prem prem = new Prem();
            prem.Show();
            this.Hide();
        }

        private void GoToEconom_Click(object sender, EventArgs e)
        {
            Econom econom = new Econom();
            econom.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CreateRequest createrequest = new CreateRequest();
            createrequest.Show();
            this.Hide();
        }

        private void Close_Click_1(object sender, EventArgs e)
        {
            Welcome welcome = new Welcome();
            welcome.Show();
            this.Hide();
        }
    }
}
